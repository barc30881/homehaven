<?php

return [
 "host"=> 'localhost',
 'port'=> 3306,
 'dbname'=> 'homehaven',
 'username'=> 'ifeanyi',
 'password'=> '123456'
];
